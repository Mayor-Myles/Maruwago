"use client";
import Link from "next/link";
import { useState } from "react";

const recentActivity = [
  { icon: "🛺", msg: "New rider registered: Tunde Adeyemi", time: "2 min ago", type: "rider" },
  { icon: "📦", msg: "Delivery MG-4830 completed successfully", time: "5 min ago", type: "delivery" },
  { icon: "🏪", msg: "New business registered: Eko Electronics", time: "12 min ago", type: "business" },
  { icon: "⚠️", msg: "Rider Bode K. flagged by customer — review needed", time: "28 min ago", type: "alert" },
  { icon: "💰", msg: "Payout processed: ₦24,500 to 18 riders", time: "1 hr ago", type: "payout" },
];

export default function AdminDashboard() {
  const [activeSection, setActiveSection] = useState("overview");

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#2A2A2E] border-r border-[#3A3A3E] flex flex-col flex-shrink-0">
        <div className="p-6 border-b border-[#3A3A3E]">
          <Link href="/" className="font-display text-2xl text-gradient">MARUWAGO</Link>
          <div className="mt-1 text-xs text-orange-400 font-semibold tracking-widest">ADMIN PANEL</div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { icon: "📊", label: "Overview", id: "overview" },
            { icon: "👥", label: "All Users", id: "users" },
            { icon: "🛺", label: "Riders", id: "riders" },
            { icon: "🏪", label: "Businesses", id: "businesses" },
            { icon: "📦", label: "All Deliveries", id: "deliveries" },
            { icon: "💰", label: "Financials", id: "finance" },
            { icon: "⚠️", label: "Reports & Flags", id: "reports" },
            { icon: "⚙️", label: "Settings", id: "settings" },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all text-left ${activeSection === item.id ? "bg-orange-500/10 text-orange-400 border border-orange-500/20" : "text-gray-400 hover:text-white hover:bg-[#3A3A3E]"}`}
            >
              <span>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-[#3A3A3E]">
          <div className="flex items-center gap-3 px-2">
            <div className="w-8 h-8 rounded-full bg-orange-500/20 border border-orange-500/50 flex items-center justify-center text-orange-400 text-xs font-bold">AD</div>
            <div>
              <div className="text-white text-xs font-semibold">Admin User</div>
              <div className="text-gray-500 text-xs">Super Admin</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-4xl text-white tracking-wide">ADMIN DASHBOARD</h1>
            <p className="text-gray-400 text-sm mt-1">Platform overview · Thursday, 27 Feb 2025</p>
          </div>
          <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/30 px-4 py-1.5 rounded-full">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-green-400 text-sm font-semibold">System Operational</span>
          </div>
        </div>

        {/* Platform stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { icon: "🛺", label: "Active Riders", value: "487", sub: "+23 this week", color: "orange" },
            { icon: "🏪", label: "Businesses", value: "1,243", sub: "+67 this month", color: "blue" },
            { icon: "📦", label: "Deliveries Today", value: "3,847", sub: "↑ 12% vs yesterday", color: "green" },
            { icon: "💰", label: "Revenue (MTD)", value: "₦4.2M", sub: "82% of target", color: "yellow" },
          ].map(s => (
            <div key={s.label} className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-5 hover:border-orange-500/20 transition-colors">
              <div className="text-2xl mb-3">{s.icon}</div>
              <div className="font-display text-3xl text-gradient">{s.value}</div>
              <div className="text-gray-400 text-xs mt-1">{s.label}</div>
              <div className="text-orange-400 text-xs mt-1">{s.sub}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Live activity */}
          <div className="col-span-2 bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl overflow-hidden">
            <div className="p-5 border-b border-[#3A3A3E] flex items-center justify-between">
              <h3 className="font-semibold text-white">Live Activity Feed</h3>
              <div className="flex items-center gap-2 text-xs text-green-400">
                <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                Live
              </div>
            </div>
            <div className="divide-y divide-[#3A3A3E]">
              {recentActivity.map((a, i) => (
                <div key={i} className="flex items-start gap-3 p-4 hover:bg-[#3A3A3E]/30 transition-colors">
                  <div className="text-xl flex-shrink-0">{a.icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-gray-300 text-sm">{a.msg}</div>
                    <div className="text-gray-600 text-xs mt-0.5">{a.time}</div>
                  </div>
                  {a.type === "alert" && (
                    <button className="text-xs text-red-400 border border-red-500/30 px-3 py-1 rounded-full hover:bg-red-500/10 transition-colors">Review</button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Quick actions + stats */}
          <div className="space-y-4">
            <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-5">
              <h3 className="font-semibold text-white mb-4">Quick Actions</h3>
              <div className="space-y-2">
                {[
                  { label: "Approve Pending Riders", count: 12, color: "orange" },
                  { label: "Resolve Reports", count: 3, color: "red" },
                  { label: "Process Payouts", count: 24, color: "green" },
                  { label: "Review Disputes", count: 2, color: "yellow" },
                ].map(a => (
                  <button key={a.label} className="w-full flex items-center justify-between bg-[#3A3A3E] hover:bg-[#4A4A4E] rounded-xl px-4 py-3 transition-colors text-left">
                    <span className="text-gray-300 text-sm">{a.label}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${a.color === "red" ? "bg-red-500/20 text-red-400" : a.color === "green" ? "bg-green-500/20 text-green-400" : a.color === "yellow" ? "bg-yellow-500/20 text-yellow-400" : "bg-orange-500/20 text-orange-400"}`}>
                      {a.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-5">
              <h3 className="font-semibold text-white mb-4">Platform Health</h3>
              <div className="space-y-3">
                {[
                  { label: "Delivery Success Rate", value: 93, color: "green" },
                  { label: "Rider Availability", value: 78, color: "orange" },
                  { label: "Customer Satisfaction", value: 89, color: "blue" },
                ].map(m => (
                  <div key={m.label}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-500">{m.label}</span>
                      <span className="text-white">{m.value}%</span>
                    </div>
                    <div className="h-1.5 bg-[#3A3A3E] rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${m.color === "green" ? "bg-green-500" : m.color === "orange" ? "bg-orange-500" : "bg-blue-500"}`} style={{width: `${m.value}%`}} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
