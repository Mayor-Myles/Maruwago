"use client";
import Link from "next/link";
import { useState } from "react";

const sizes = [
  { id: "small", label: "Small", desc: "Documents, small items", icon: "📄", price: "₦600" },
  { id: "medium", label: "Medium", desc: "Clothes, shoes, gifts", icon: "📦", price: "₦900" },
  { id: "large", label: "Large", desc: "Electronics, bulk items", icon: "📫", price: "₦1,400" },
  { id: "extra", label: "Extra Large", desc: "Industrial goods", icon: "🏗️", price: "₦2,000+" },
];

export default function BookDeliveryPage() {
  const [step, setStep] = useState(1);
  const [selectedSize, setSelectedSize] = useState("medium");
  const [priority, setPriority] = useState("standard");

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body">
      {/* Top nav */}
      <div className="border-b border-[#2A2A2E] px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/business" className="text-gray-400 hover:text-white text-sm transition-colors">← Dashboard</Link>
          <div className="w-px h-5 bg-[#3A3A3E]" />
          <div className="font-display text-xl text-gradient">BOOK DELIVERY</div>
        </div>
        <div className="flex items-center gap-2">
          {[1, 2, 3].map(s => (
            <div key={s} className="flex items-center gap-1">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${step >= s ? "bg-orange-500 text-white" : "bg-[#2A2A2E] text-gray-500 border border-[#3A3A3E]"}`}>{s}</div>
              {s < 3 && <div className={`w-8 h-px ${step > s ? "bg-orange-500" : "bg-[#3A3A3E]"}`} />}
            </div>
          ))}
          <span className="ml-2 text-sm text-gray-400">{["Addresses", "Package", "Confirm"][step-1]}</span>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-6 py-12">
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-4xl text-white tracking-wide mb-1">PICKUP & DELIVERY</h2>
              <p className="text-gray-400 text-sm">Where should we pick up and drop off?</p>
            </div>

            <div className="space-y-4">
              <div className="relative">
                <label className="block text-sm text-gray-400 mb-2">Pickup Address</label>
                <div className="flex gap-3">
                  <div className="flex flex-col items-center gap-1 pt-3.5">
                    <div className="w-3 h-3 rounded-full border-2 border-orange-500" />
                    <div className="w-px h-8 bg-orange-500/30" />
                  </div>
                  <input
                    className="flex-1 bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 outline-none"
                    placeholder="Enter pickup address or landmark"
                  />
                </div>
              </div>

              <div className="relative">
                <label className="block text-sm text-gray-400 mb-2">Dropoff Address</label>
                <div className="flex gap-3">
                  <div className="flex flex-col items-center pt-3.5">
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                  </div>
                  <input
                    className="flex-1 bg-[#2A2A2E] border border-[#3A3A3E] focus:border-green-500 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 outline-none"
                    placeholder="Enter delivery address or landmark"
                  />
                </div>
              </div>

              <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-xl p-4">
                <div className="text-sm text-gray-400 mb-3">Recipient Contact</div>
                <div className="grid grid-cols-2 gap-3">
                  <input className="bg-[#1C1C1E] border border-[#3A3A3E] rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none text-sm" placeholder="Recipient Name" />
                  <input className="bg-[#1C1C1E] border border-[#3A3A3E] rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none text-sm" placeholder="Phone Number" />
                </div>
              </div>

              {/* Map placeholder */}
              <div className="h-40 bg-[#2A2A2E] border border-[#3A3A3E] rounded-xl flex items-center justify-center text-gray-600 text-sm">
                🗺️ Interactive map will appear here
              </div>
            </div>

            <button onClick={() => setStep(2)} className="w-full bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold py-3.5 rounded-xl transition-all hover:shadow-xl hover:shadow-orange-500/30">
              Continue →
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-4xl text-white tracking-wide mb-1">PACKAGE DETAILS</h2>
              <p className="text-gray-400 text-sm">What are you sending?</p>
            </div>

            <div>
              <div className="text-sm text-gray-400 mb-3">Package Size</div>
              <div className="grid grid-cols-2 gap-3">
                {sizes.map(s => (
                  <button
                    key={s.id}
                    onClick={() => setSelectedSize(s.id)}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${selectedSize === s.id ? "border-orange-500 bg-orange-500/10" : "border-[#3A3A3E] bg-[#2A2A2E] hover:border-[#5A5A5E]"}`}
                  >
                    <div className="text-2xl mb-2">{s.icon}</div>
                    <div className="font-semibold text-white text-sm">{s.label}</div>
                    <div className="text-gray-500 text-xs mt-0.5">{s.desc}</div>
                    <div className="text-orange-400 font-semibold text-sm mt-2">{s.price}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="text-sm text-gray-400 mb-3">Delivery Priority</div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: "standard", label: "Standard", desc: "30–60 min", extra: "Base price" },
                  { id: "express", label: "Express ⚡", desc: "15–25 min", extra: "+₦300" },
                ].map(p => (
                  <button
                    key={p.id}
                    onClick={() => setPriority(p.id)}
                    className={`p-4 rounded-xl border-2 text-left transition-all ${priority === p.id ? "border-orange-500 bg-orange-500/10" : "border-[#3A3A3E] bg-[#2A2A2E] hover:border-[#5A5A5E]"}`}
                  >
                    <div className="font-semibold text-white text-sm">{p.label}</div>
                    <div className="text-gray-500 text-xs mt-1">{p.desc}</div>
                    <div className="text-orange-400 text-xs mt-1">{p.extra}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Package Description (optional)</label>
              <textarea
                className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none resize-none"
                rows={3}
                placeholder="Describe what you're sending (e.g. 'Fragile electronics, handle with care')"
              />
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep(1)} className="flex-1 border border-[#3A3A3E] text-gray-300 hover:border-[#5A5A5E] font-semibold py-3.5 rounded-xl transition-all">← Back</button>
              <button onClick={() => setStep(3)} className="flex-[2] bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold py-3.5 rounded-xl transition-all hover:shadow-xl hover:shadow-orange-500/30">Review Order →</button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="font-display text-4xl text-white tracking-wide mb-1">CONFIRM ORDER</h2>
              <p className="text-gray-400 text-sm">Review your delivery details before booking</p>
            </div>

            <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl overflow-hidden">
              <div className="p-5 space-y-4">
                <div className="flex gap-3">
                  <div className="flex flex-col items-center gap-1 pt-1">
                    <div className="w-3 h-3 rounded-full border-2 border-orange-500" />
                    <div className="w-px h-6 bg-orange-500/30" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                  </div>
                  <div className="space-y-4">
                    <div>
                      <div className="text-gray-500 text-xs">PICKUP</div>
                      <div className="text-white text-sm mt-0.5">32 Allen Avenue, Ikeja, Lagos</div>
                    </div>
                    <div>
                      <div className="text-gray-500 text-xs">DROPOFF</div>
                      <div className="text-white text-sm mt-0.5">15 Broad Street, Lagos Island</div>
                    </div>
                  </div>
                </div>
                <div className="border-t border-[#3A3A3E] pt-4 grid grid-cols-3 gap-4 text-center text-sm">
                  <div><div className="text-gray-500 text-xs mb-1">SIZE</div><div className="text-white font-medium">Medium</div></div>
                  <div><div className="text-gray-500 text-xs mb-1">PRIORITY</div><div className="text-orange-400 font-medium">Standard</div></div>
                  <div><div className="text-gray-500 text-xs mb-1">DISTANCE</div><div className="text-white font-medium">~14.2 km</div></div>
                </div>
              </div>
              <div className="border-t border-[#3A3A3E] p-5 bg-[#1C1C1E] flex items-center justify-between">
                <div>
                  <div className="text-gray-500 text-xs">TOTAL PRICE</div>
                  <div className="font-display text-3xl text-gradient">₦1,200</div>
                </div>
                <div className="text-gray-500 text-xs text-right">ETA after booking:<br/><span className="text-white text-sm">~22 min pickup</span></div>
              </div>
            </div>

            <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-xl p-4">
              <div className="text-sm text-gray-400 mb-3">Payment Method</div>
              <div className="flex gap-3">
                {["Wallet (₦45,200)", "Pay on Delivery", "Card"].map(m => (
                  <button key={m} className={`flex-1 py-2.5 rounded-lg text-xs font-medium border transition-all ${m.includes("Wallet") ? "border-orange-500 bg-orange-500/10 text-orange-400" : "border-[#3A3A3E] text-gray-400 hover:border-[#5A5A5E]"}`}>{m}</button>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep(2)} className="flex-1 border border-[#3A3A3E] text-gray-300 hover:border-[#5A5A5E] font-semibold py-3.5 rounded-xl transition-all">← Back</button>
              <Link href="/track/MG-4830" className="flex-[2] bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold py-3.5 rounded-xl text-center transition-all hover:shadow-xl hover:shadow-orange-500/30">
                🛺 Place Order
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
