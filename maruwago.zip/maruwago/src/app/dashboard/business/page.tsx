"use client";
import Link from "next/link";
import { useState } from "react";

const recentDeliveries = [
  { id: "MG-4821", from: "32 Allen Ave, Ikeja", to: "15 Broad St, Lagos Island", status: "delivered", rider: "Chukwudi O.", time: "2 hrs ago", cost: "₦1,200" },
  { id: "MG-4820", from: "Shop 5 Trade Fair", to: "Apapa Wharf Gate", status: "in_transit", rider: "Emeka T.", time: "45 mins", cost: "₦900" },
  { id: "MG-4819", from: "32 Allen Ave, Ikeja", to: "27 Awolowo Rd, Ikoyi", status: "delivered", rider: "Bayo S.", time: "Yesterday", cost: "₦1,500" },
  { id: "MG-4818", from: "32 Allen Ave, Ikeja", to: "Sabo Market, Yaba", status: "cancelled", rider: "—", time: "Yesterday", cost: "₦0" },
];

const statusColors = {
  delivered: "text-green-400 bg-green-400/10",
  in_transit: "text-orange-400 bg-orange-400/10",
  cancelled: "text-red-400 bg-red-400/10",
  pending: "text-yellow-400 bg-yellow-400/10",
};
const statusLabels = {
  delivered: "Delivered",
  in_transit: "In Transit",
  cancelled: "Cancelled",
  pending: "Pending",
};

export default function BusinessDashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#2A2A2E] border-r border-[#3A3A3E] flex-shrink-0 flex flex-col">
        <div className="p-6 border-b border-[#3A3A3E]">
          <Link href="/" className="font-display text-2xl text-gradient">MARUWAGO</Link>
          <div className="mt-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-500/20 border border-orange-500/50 flex items-center justify-center text-orange-400 font-bold">A</div>
            <div>
              <div className="text-white text-sm font-semibold">Adaora's Store</div>
              <div className="text-gray-500 text-xs">Business Account</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { icon: "📊", label: "Overview", id: "overview", href: "/dashboard/business" },
            { icon: "📦", label: "Book Delivery", id: "book", href: "/book" },
            { icon: "📍", label: "Track Orders", id: "track", href: "/track/MG-4820" },
            { icon: "🕐", label: "History", id: "history", href: "/history" },
            { icon: "👤", label: "Profile", id: "profile", href: "/profile" },
          ].map(item => (
            <Link
              key={item.id}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all ${activeTab === item.id ? "bg-orange-500/10 text-orange-400 border border-orange-500/20" : "text-gray-400 hover:text-white hover:bg-[#3A3A3E]"}`}
              onClick={() => setActiveTab(item.id)}
            >
              <span>{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-[#3A3A3E]">
          <Link href="/login" className="flex items-center gap-3 px-4 py-3 text-gray-500 hover:text-red-400 text-sm transition-colors">
            <span>🚪</span> Sign Out
          </Link>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-4xl text-white tracking-wide">GOOD MORNING, ADAORA 👋</h1>
            <p className="text-gray-400 text-sm mt-1">Thursday, 27 Feb 2025 · Lagos</p>
          </div>
          <Link href="/book" className="bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold px-6 py-3 rounded-xl transition-all hover:shadow-lg hover:shadow-orange-500/30 flex items-center gap-2">
            <span>+</span> Book Delivery
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { icon: "📦", label: "Total Deliveries", value: "248", change: "+12 this week" },
            { icon: "✅", label: "Completed", value: "231", change: "93.1% success rate" },
            { icon: "🚚", label: "Active Orders", value: "3", change: "2 in transit" },
            { icon: "💰", label: "Total Spent", value: "₦182,400", change: "+₦24,300 this month" },
          ].map(s => (
            <div key={s.label} className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-5 hover:border-orange-500/20 transition-colors">
              <div className="text-2xl mb-3">{s.icon}</div>
              <div className="font-display text-3xl text-white">{s.value}</div>
              <div className="text-gray-400 text-xs mt-1">{s.label}</div>
              <div className="text-orange-400 text-xs mt-1">{s.change}</div>
            </div>
          ))}
        </div>

        {/* Active delivery banner */}
        <div className="bg-orange-500/10 border border-orange-500/30 rounded-2xl p-5 mb-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center text-xl animate-pulse">🛺</div>
            <div>
              <div className="text-orange-400 font-semibold">Active Delivery — MG-4820</div>
              <div className="text-gray-300 text-sm">Emeka T. is on the way to Apapa Wharf Gate</div>
              <div className="text-gray-500 text-xs mt-0.5">ETA: ~18 minutes · Last seen at Oshodi</div>
            </div>
          </div>
          <Link href="/track/MG-4820" className="bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl transition-all">
            Track Live →
          </Link>
        </div>

        {/* Recent deliveries */}
        <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl overflow-hidden">
          <div className="p-5 border-b border-[#3A3A3E] flex items-center justify-between">
            <h2 className="font-semibold text-white">Recent Deliveries</h2>
            <Link href="/history" className="text-orange-400 text-sm hover:text-orange-300">View All →</Link>
          </div>
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#3A3A3E]">
                {["Order ID", "From", "To", "Rider", "Status", "Cost", "Time"].map(h => (
                  <th key={h} className="text-left px-5 py-3 text-gray-500 text-xs font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentDeliveries.map(d => (
                <tr key={d.id} className="border-b border-[#3A3A3E] hover:bg-[#3A3A3E]/30 transition-colors">
                  <td className="px-5 py-4 text-orange-400 text-sm font-mono">{d.id}</td>
                  <td className="px-5 py-4 text-gray-300 text-sm max-w-[120px] truncate">{d.from}</td>
                  <td className="px-5 py-4 text-gray-300 text-sm max-w-[120px] truncate">{d.to}</td>
                  <td className="px-5 py-4 text-gray-300 text-sm">{d.rider}</td>
                  <td className="px-5 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[d.status as keyof typeof statusColors]}`}>
                      {statusLabels[d.status as keyof typeof statusLabels]}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-white text-sm font-medium">{d.cost}</td>
                  <td className="px-5 py-4 text-gray-500 text-xs">{d.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
