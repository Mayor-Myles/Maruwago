"use client";
import Link from "next/link";
import { useState } from "react";

const availableJobs = [
  { id: "MG-4825", pickup: "32 Allen Ave, Ikeja", dropoff: "15 Broad St, Lagos Island", dist: "14.2 km", est: "22 min", pay: "₦1,400", size: "Medium", urgency: "Standard" },
  { id: "MG-4826", pickup: "Trade Fair Complex", dropoff: "Apapa Port Gate 3", dist: "8.5 km", est: "15 min", pay: "₦900", size: "Small", urgency: "Express" },
  { id: "MG-4827", pickup: "Lekki Phase 1", dropoff: "Sangotedo", dist: "11.3 km", est: "18 min", pay: "₦1,100", size: "Large", urgency: "Standard" },
];

export default function RiderDashboard() {
  const [online, setOnline] = useState(true);
  const [acceptedJob, setAcceptedJob] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#2A2A2E] border-r border-[#3A3A3E] flex-shrink-0 flex flex-col">
        <div className="p-6 border-b border-[#3A3A3E]">
          <Link href="/" className="font-display text-2xl text-gradient">MARUWAGO</Link>
          <div className="mt-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-500/20 border border-orange-500/50 flex items-center justify-center text-orange-400 font-bold">E</div>
            <div>
              <div className="text-white text-sm font-semibold">Emeka Okafor</div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className={`w-2 h-2 rounded-full ${online ? "bg-green-400" : "bg-gray-500"}`} />
                <span className={`text-xs ${online ? "text-green-400" : "text-gray-500"}`}>{online ? "Online" : "Offline"}</span>
              </div>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { icon: "🏠", label: "Dashboard", href: "/dashboard/rider" },
            { icon: "📦", label: "Active Job", href: "/track/MG-4820" },
            { icon: "💰", label: "Earnings", href: "/profile" },
            { icon: "⭐", label: "My Rating", href: "/profile" },
            { icon: "👤", label: "Profile", href: "/profile" },
          ].map(item => (
            <Link key={item.label} href={item.href} className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-gray-400 hover:text-white hover:bg-[#3A3A3E] transition-all">
              <span>{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Online toggle */}
        <div className="p-4 border-t border-[#3A3A3E]">
          <div className="flex items-center justify-between px-4 py-3 bg-[#3A3A3E] rounded-xl">
            <span className="text-sm text-gray-300">Go {online ? "Offline" : "Online"}</span>
            <button
              onClick={() => setOnline(!online)}
              className={`w-12 h-6 rounded-full transition-all duration-300 relative ${online ? "bg-green-500" : "bg-gray-600"}`}
            >
              <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all duration-300 ${online ? "left-6" : "left-0.5"}`} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-4xl text-white tracking-wide">RIDER HUB</h1>
            <p className="text-gray-400 text-sm mt-1">Thursday, 27 Feb 2025 · Ikeja Area</p>
          </div>
          <div className={`flex items-center gap-2 px-4 py-2 rounded-full border ${online ? "border-green-500/30 bg-green-500/10 text-green-400" : "border-gray-500/30 bg-gray-500/10 text-gray-400"}`}>
            <div className={`w-2 h-2 rounded-full ${online ? "bg-green-400 animate-pulse" : "bg-gray-500"}`} />
            <span className="text-sm font-semibold">{online ? "Available for Jobs" : "Offline"}</span>
          </div>
        </div>

        {/* Today's stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { icon: "✅", label: "Jobs Today", value: "7" },
            { icon: "💰", label: "Earned Today", value: "₦8,750" },
            { icon: "⭐", label: "Rating", value: "4.8" },
            { icon: "📍", label: "KM Covered", value: "62 km" },
          ].map(s => (
            <div key={s.label} className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-5 hover:border-orange-500/20 transition-colors">
              <div className="text-2xl mb-3">{s.icon}</div>
              <div className="font-display text-3xl text-gradient">{s.value}</div>
              <div className="text-gray-400 text-xs mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Available Jobs */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-white text-lg">
              Available Jobs Near You 
              <span className="ml-2 text-xs text-orange-400 bg-orange-400/10 px-2 py-0.5 rounded-full">{availableJobs.length} nearby</span>
            </h2>
          </div>
          <div className="space-y-3">
            {availableJobs.map(job => (
              <div key={job.id} className={`bg-[#2A2A2E] border rounded-2xl p-5 transition-all ${acceptedJob === job.id ? "border-green-500/50 bg-green-500/5" : "border-[#3A3A3E] hover:border-orange-500/30"}`}>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-mono text-orange-400 text-sm">{job.id}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${job.urgency === "Express" ? "bg-yellow-500/10 text-yellow-400" : "bg-gray-500/10 text-gray-400"}`}>
                        {job.urgency}
                      </span>
                      <span className="text-xs bg-[#3A3A3E] text-gray-400 px-2 py-0.5 rounded-full">{job.size}</span>
                    </div>
                    <div className="space-y-1.5 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-orange-400">▲</span>
                        <span className="text-gray-300">{job.pickup}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400">▼</span>
                        <span className="text-gray-300">{job.dropoff}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                      <span>📍 {job.dist}</span>
                      <span>⏱ Est. {job.est}</span>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="font-display text-2xl text-gradient mb-3">{job.pay}</div>
                    {acceptedJob === job.id ? (
                      <Link href="/track/MG-4820" className="block bg-green-500 text-white text-sm font-semibold px-5 py-2.5 rounded-xl">
                        Go to Job →
                      </Link>
                    ) : (
                      <button
                        onClick={() => setAcceptedJob(job.id)}
                        className="bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl transition-all hover:shadow-lg hover:shadow-orange-500/20"
                      >
                        Accept
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Weekly earnings chart placeholder */}
        <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-5">
          <h3 className="font-semibold text-white mb-4">This Week's Earnings</h3>
          <div className="flex items-end gap-3 h-28">
            {[45, 72, 55, 88, 65, 92, 87].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                <div
                  className={`w-full rounded-t-lg transition-all ${i === 6 ? "bg-orange-500" : "bg-[#3A3A3E]"}`}
                  style={{height: `${h}%`}}
                />
                <span className="text-gray-500 text-xs">{["M","T","W","T","F","S","S"][i]}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-between text-sm">
            <span className="text-gray-500">This week total</span>
            <span className="text-gradient font-display text-xl">₦52,300</span>
          </div>
        </div>
      </main>
    </div>
  );
}
