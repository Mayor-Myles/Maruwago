"use client";
import Link from "next/link";
import { useState } from "react";

const deliveries = [
  { id: "MG-4821", from: "32 Allen Ave, Ikeja", to: "15 Broad St, Lagos Island", status: "delivered", rider: "Chukwudi O.", date: "27 Feb 2025", cost: "₦1,200", size: "Medium" },
  { id: "MG-4820", from: "Shop 5 Trade Fair", to: "Apapa Wharf Gate", status: "in_transit", rider: "Emeka T.", date: "27 Feb 2025", cost: "₦900", size: "Small" },
  { id: "MG-4819", from: "32 Allen Ave, Ikeja", to: "27 Awolowo Rd, Ikoyi", status: "delivered", rider: "Bayo S.", date: "26 Feb 2025", cost: "₦1,500", size: "Large" },
  { id: "MG-4818", from: "32 Allen Ave, Ikeja", to: "Sabo Market, Yaba", status: "cancelled", rider: "—", date: "26 Feb 2025", cost: "₦0", size: "Small" },
  { id: "MG-4815", from: "Lekki Phase 1", to: "Sangotedo Market", status: "delivered", rider: "Tunde A.", date: "25 Feb 2025", cost: "₦1,100", size: "Medium" },
  { id: "MG-4812", from: "32 Allen Ave, Ikeja", to: "Computer Village", status: "delivered", rider: "Emeka T.", date: "25 Feb 2025", cost: "₦700", size: "Small" },
  { id: "MG-4809", from: "Balogun Market", to: "32 Allen Ave, Ikeja", status: "delivered", rider: "Chukwudi O.", date: "24 Feb 2025", cost: "₦1,800", size: "Extra Large" },
];

const statusColors = {
  delivered: "text-green-400 bg-green-400/10",
  in_transit: "text-orange-400 bg-orange-400/10",
  cancelled: "text-red-400 bg-red-400/10",
};

export default function HistoryPage() {
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  const filtered = deliveries.filter(d => {
    if (filter !== "all" && d.status !== filter) return false;
    if (search && !d.id.toLowerCase().includes(search.toLowerCase()) && !d.to.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const totalSpent = deliveries.filter(d => d.status === "delivered").reduce((sum, d) => sum + parseInt(d.cost.replace(/[₦,]/g, "") || "0"), 0);

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body">
      <div className="border-b border-[#2A2A2E] px-8 h-16 flex items-center gap-4">
        <Link href="/dashboard/business" className="text-gray-400 hover:text-white text-sm">← Dashboard</Link>
        <div className="w-px h-5 bg-[#3A3A3E]" />
        <div className="font-display text-xl text-gradient">DELIVERY HISTORY</div>
      </div>

      <div className="max-w-6xl mx-auto px-8 py-8">
        {/* Summary stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Orders", value: deliveries.length.toString() },
            { label: "Delivered", value: deliveries.filter(d => d.status === "delivered").length.toString() },
            { label: "Cancelled", value: deliveries.filter(d => d.status === "cancelled").length.toString() },
            { label: "Total Spent", value: `₦${totalSpent.toLocaleString()}` },
          ].map(s => (
            <div key={s.label} className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-5">
              <div className="font-display text-3xl text-gradient">{s.value}</div>
              <div className="text-gray-400 text-xs mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
          <div className="flex gap-2">
            {["all", "delivered", "in_transit", "cancelled"].map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${filter === f ? "bg-orange-500 text-white" : "bg-[#2A2A2E] border border-[#3A3A3E] text-gray-400 hover:text-white"}`}
              >
                {f === "all" ? "All" : f === "in_transit" ? "In Transit" : f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by order ID or destination..."
            className="bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-2.5 text-white placeholder-gray-600 outline-none text-sm w-72"
          />
        </div>

        {/* Table */}
        <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#3A3A3E]">
                {["Order ID", "From", "To", "Rider", "Date", "Size", "Status", "Cost", ""].map(h => (
                  <th key={h} className="text-left px-5 py-4 text-gray-500 text-xs font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(d => (
                <tr key={d.id} className="border-b border-[#3A3A3E] hover:bg-[#3A3A3E]/30 transition-colors">
                  <td className="px-5 py-4 text-orange-400 text-sm font-mono">{d.id}</td>
                  <td className="px-5 py-4 text-gray-400 text-sm max-w-[100px] truncate">{d.from}</td>
                  <td className="px-5 py-4 text-gray-300 text-sm max-w-[120px] truncate">{d.to}</td>
                  <td className="px-5 py-4 text-gray-300 text-sm">{d.rider}</td>
                  <td className="px-5 py-4 text-gray-500 text-xs">{d.date}</td>
                  <td className="px-5 py-4 text-gray-400 text-sm">{d.size}</td>
                  <td className="px-5 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[d.status as keyof typeof statusColors]}`}>
                      {d.status === "in_transit" ? "In Transit" : d.status.charAt(0).toUpperCase() + d.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-white font-medium">{d.cost}</td>
                  <td className="px-5 py-4">
                    {d.status === "in_transit" && (
                      <Link href={`/track/${d.id}`} className="text-orange-400 text-xs hover:text-orange-300 font-medium">Track →</Link>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-16 text-gray-500">No deliveries found matching your filters.</div>
          )}
        </div>
      </div>
    </div>
  );
}
