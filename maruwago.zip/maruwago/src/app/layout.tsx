import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MaruwaGo — Tricycle Delivery, Redefined",
  description: "Connect your business with Maruwa riders for fast, reliable delivery across the city.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
