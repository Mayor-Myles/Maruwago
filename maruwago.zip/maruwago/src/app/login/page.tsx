"use client";
import Link from "next/link";
import { useState } from "react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="min-h-screen bg-[#1C1C1E] flex font-body">
      {/* Left panel */}
      <div className="hidden lg:flex w-1/2 relative bg-[#2A2A2E] items-center justify-center overflow-hidden">
        <div className="absolute inset-0" style={{backgroundImage: "linear-gradient(rgba(249,115,22,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(249,115,22,0.05) 1px, transparent 1px)", backgroundSize: "60px 60px"}} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-orange-500/10 rounded-full blur-[80px]" />
        <div className="relative text-center space-y-6 px-12">
          <div className="font-display text-8xl">🛺</div>
          <div className="font-display text-5xl text-gradient leading-none">DELIVERY<br/>AT YOUR<br/>FINGERTIPS</div>
          <p className="text-gray-400 max-w-xs mx-auto">Fast, affordable Maruwa-powered delivery for Nigerian businesses.</p>
        </div>
        <div className="absolute bottom-8 left-8">
          <Link href="/" className="font-display text-3xl tracking-wider text-gradient">MARUWAGO</Link>
        </div>
      </div>

      {/* Right panel */}
      <div className="w-full lg:w-1/2 flex items-center justify-center px-8 py-12">
        <div className="w-full max-w-sm">
          <div className="lg:hidden mb-8">
            <Link href="/" className="font-display text-3xl text-gradient">MARUWAGO</Link>
          </div>
          
          <div className="mb-8">
            <h1 className="font-display text-5xl text-white tracking-wide mb-2">WELCOME BACK</h1>
            <p className="text-gray-400">Sign in to your MaruwaGo account</p>
          </div>

          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 outline-none transition-colors"
              />
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm text-gray-400">Password</label>
                <a href="#" className="text-xs text-orange-400 hover:text-orange-300">Forgot password?</a>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 outline-none transition-colors"
              />
            </div>

            <Link href="/dashboard/business" className="block w-full bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold py-3.5 rounded-xl text-center transition-all hover:shadow-xl hover:shadow-orange-500/30">
              Sign In
            </Link>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-[#3A3A3E]" /></div>
            <div className="relative text-center"><span className="bg-[#1C1C1E] px-4 text-gray-500 text-sm">or continue with</span></div>
          </div>

          <button className="w-full border border-[#3A3A3E] hover:border-orange-500/30 text-gray-300 py-3.5 rounded-xl font-medium transition-all flex items-center justify-center gap-3">
            <span>🔑</span> Continue with Google
          </button>

          <p className="text-center text-gray-500 text-sm mt-8">
            Don't have an account?{" "}
            <Link href="/register" className="text-orange-400 hover:text-orange-300 font-semibold">Create one free</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
