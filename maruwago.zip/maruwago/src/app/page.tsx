"use client";
import Link from "next/link";
import { useState, useEffect } from "react";

const stats = [
  { value: "500+", label: "Active Riders" },
  { value: "2,400+", label: "Deliveries Done" },
  { value: "98%", label: "On-Time Rate" },
  { value: "12 Cities", label: "Coverage Areas" },
];

const steps = [
  { num: "01", title: "Register Your Business", desc: "Sign up as a business owner or individual. Takes less than 3 minutes." },
  { num: "02", title: "Book a Delivery", desc: "Enter pickup, dropoff, package details. Our system matches you with the nearest rider." },
  { num: "03", title: "Track in Real-Time", desc: "Follow your Maruwa rider live on the map. Get notified every step of the way." },
  { num: "04", title: "Delivered & Confirmed", desc: "Recipient confirms delivery. Pay seamlessly. Rate your rider experience." },
];

const testimonials = [
  { name: "Adaora Nwosu", role: "Boutique Owner, Lagos", text: "MaruwaGo changed how I handle same-day deliveries. My customers are happier and I save so much stress." },
  { name: "Emeka Okafor", role: "Maruwa Rider, Onitsha", text: "Before MaruwaGo I'd park for hours with nothing. Now I have consistent jobs every day. My income tripled." },
  { name: "Fatima Bello", role: "Online Store Owner, Abuja", text: "The booking is so easy. I book from my phone and my packages go out within 20 minutes. Incredible service." },
];

export default function Home() {
  const [activeRole, setActiveRole] = useState<"business" | "rider">("business");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#1C1C1E] text-white font-body overflow-x-hidden">

      {/* ── NAV ── */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "bg-[#1C1C1E]/95 backdrop-blur border-b border-[#3A3A3E]" : "bg-transparent"}`}>
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/" className="font-display text-3xl tracking-wider text-gradient">
            MARUWA<span className="text-white">GO</span>
          </Link>
          <div className="hidden md:flex items-center gap-8 text-sm text-gray-400">
            <a href="#how" className="hover:text-white transition-colors">How It Works</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
            <a href="#riders" className="hover:text-white transition-colors">Become a Rider</a>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/login" className="text-sm text-gray-300 hover:text-white px-4 py-2 transition-colors">
              Log In
            </Link>
            <Link href="/register" className="bg-[#F97316] hover:bg-[#FF4500] text-white text-sm font-semibold px-5 py-2 rounded-full transition-all duration-200 hover:shadow-lg hover:shadow-orange-500/30">
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
        {/* Grid background */}
        <div className="absolute inset-0"
          style={{backgroundImage: "linear-gradient(rgba(249,115,22,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(249,115,22,0.05) 1px, transparent 1px)", backgroundSize: "60px 60px"}}>
        </div>
        {/* Orange radial glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-orange-500/10 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="relative max-w-7xl mx-auto px-6 py-24 grid md:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 bg-orange-500/10 border border-orange-500/30 rounded-full px-4 py-1.5 text-sm text-orange-400">
              <span className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" />
              Now live in 12 Nigerian cities
            </div>
            <h1 className="font-display text-7xl md:text-8xl leading-none tracking-wide">
              DELIVERY<br/>
              <span className="text-gradient">POWERED</span><br/>
              BY MARUWA
            </h1>
            <p className="text-gray-400 text-lg leading-relaxed max-w-md">
              Connect your SME with trusted Maruwa riders for same-day delivery. 
              Fast, affordable, and built for Nigerian businesses.
            </p>

            {/* Role Switcher */}
            <div className="bg-[#2A2A2E] p-1.5 rounded-full flex w-fit gap-1">
              <button
                onClick={() => setActiveRole("business")}
                className={`px-6 py-2.5 rounded-full text-sm font-semibold transition-all duration-300 ${activeRole === "business" ? "bg-[#F97316] text-white shadow-lg shadow-orange-500/30" : "text-gray-400 hover:text-white"}`}>
                For Business
              </button>
              <button
                onClick={() => setActiveRole("rider")}
                className={`px-6 py-2.5 rounded-full text-sm font-semibold transition-all duration-300 ${activeRole === "rider" ? "bg-[#F97316] text-white shadow-lg shadow-orange-500/30" : "text-gray-400 hover:text-white"}`}>
                For Riders
              </button>
            </div>

            <div className="flex gap-4 flex-wrap">
              {activeRole === "business" ? (
                <>
                  <Link href="/register?role=business" className="bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold px-8 py-3.5 rounded-full transition-all duration-200 hover:shadow-xl hover:shadow-orange-500/30 hover:-translate-y-0.5">
                    Start Sending Packages →
                  </Link>
                  <a href="#how" className="border border-[#3A3A3E] text-gray-300 hover:border-orange-500/50 hover:text-white font-semibold px-8 py-3.5 rounded-full transition-all duration-200">
                    See How It Works
                  </a>
                </>
              ) : (
                <>
                  <Link href="/register?role=rider" className="bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold px-8 py-3.5 rounded-full transition-all duration-200 hover:shadow-xl hover:shadow-orange-500/30 hover:-translate-y-0.5">
                    Register as a Rider →
                  </Link>
                  <a href="#riders" className="border border-[#3A3A3E] text-gray-300 hover:border-orange-500/50 hover:text-white font-semibold px-8 py-3.5 rounded-full transition-all duration-200">
                    Learn More
                  </a>
                </>
              )}
            </div>
          </div>

          {/* Hero Visual */}
          <div className="relative flex justify-center items-center">
            <div className="relative w-72 h-72 md:w-96 md:h-96">
              {/* Outer ring */}
              <div className="absolute inset-0 rounded-full border-2 border-dashed border-orange-500/20 animate-spin" style={{animationDuration: "20s"}} />
              {/* Middle ring */}
              <div className="absolute inset-8 rounded-full border border-orange-500/30" />
              {/* Center */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-3xl p-10 text-center orange-glow">
                  <div className="font-display text-8xl text-gradient">🛺</div>
                  <div className="font-display text-2xl tracking-wider mt-2 text-orange-400">ON THE WAY</div>
                </div>
              </div>
              {/* Floating cards */}
              <div className="absolute -top-4 -right-4 bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl px-4 py-3 text-xs">
                <div className="text-orange-400 font-semibold">📍 Picked Up</div>
                <div className="text-gray-400 mt-0.5">2 mins ago</div>
              </div>
              <div className="absolute -bottom-4 -left-4 bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl px-4 py-3 text-xs">
                <div className="text-green-400 font-semibold">✓ ETA: 18 mins</div>
                <div className="text-gray-400 mt-0.5">Rider: Chukwu O.</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <section className="border-y border-[#2A2A2E] bg-[#2A2A2E]/50">
        <div className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <div className="font-display text-5xl text-gradient">{s.value}</div>
              <div className="text-gray-400 text-sm mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section id="how" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <p className="text-orange-400 text-sm font-semibold tracking-widest uppercase mb-3">The Process</p>
            <h2 className="font-display text-6xl text-white">HOW MARUWAGO<br/><span className="text-gradient">WORKS</span></h2>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {steps.map((step, i) => (
              <div key={step.num} className="relative group">
                <div className="bg-[#2A2A2E] border border-[#3A3A3E] group-hover:border-orange-500/50 rounded-2xl p-6 h-full transition-all duration-300 group-hover:-translate-y-1">
                  <div className="font-display text-5xl text-orange-500/30 group-hover:text-orange-500/60 transition-colors mb-4">{step.num}</div>
                  <h3 className="font-semibold text-white mb-2">{step.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{step.desc}</p>
                </div>
                {i < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-3 w-6 h-px bg-orange-500/30" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FOR RIDERS ── */}
      <section id="riders" className="py-24 px-6 bg-[#2A2A2E]/30">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-orange-400 text-sm font-semibold tracking-widest uppercase mb-3">For Maruwa Owners</p>
            <h2 className="font-display text-6xl leading-none mb-6">
              EARN MORE.<br/><span className="text-gradient">RIDE SMART.</span>
            </h2>
            <p className="text-gray-400 leading-relaxed mb-8 max-w-md">
              Join hundreds of Maruwa riders making consistent income. No guesswork — 
              our platform connects you directly with delivery jobs near you. Work when you want, earn what you deserve.
            </p>
            <div className="space-y-4 mb-8">
              {["Set your own hours and availability", "Get paid per delivery — fast payouts", "Build a rating that attracts more jobs", "Join a community of professional riders"].map(b => (
                <div key={b} className="flex items-center gap-3 text-gray-300">
                  <div className="w-5 h-5 rounded-full bg-orange-500/20 border border-orange-500/50 flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 rounded-full bg-orange-500" />
                  </div>
                  {b}
                </div>
              ))}
            </div>
            <Link href="/register?role=rider" className="inline-block bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold px-8 py-3.5 rounded-full transition-all hover:shadow-xl hover:shadow-orange-500/30">
              Join as a Rider →
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: "💰", label: "Avg. Daily Earnings", value: "₦8,500" },
              { icon: "📦", label: "Jobs Per Day", value: "12–18" },
              { icon: "⭐", label: "Top Rider Rating", value: "4.9/5" },
              { icon: "🚀", label: "Payout Speed", value: "Same Day" },
            ].map(c => (
              <div key={c.label} className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-6 text-center hover:border-orange-500/30 transition-colors">
                <div className="text-3xl mb-2">{c.icon}</div>
                <div className="font-display text-2xl text-gradient">{c.value}</div>
                <div className="text-gray-400 text-xs mt-1">{c.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ── */}
      <section id="pricing" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 text-center">
            <p className="text-orange-400 text-sm font-semibold tracking-widest uppercase mb-3">Simple Pricing</p>
            <h2 className="font-display text-6xl">PLANS FOR<br/><span className="text-gradient">EVERY BUSINESS</span></h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "STARTER", price: "Free", note: "per delivery fee applies", features: ["Up to 10 deliveries/month", "Basic tracking", "Email support", "1 user account"], cta: "Get Started Free" },
              { name: "BUSINESS", price: "₦15,000", note: "/month", features: ["Unlimited deliveries", "Live GPS tracking", "Priority rider matching", "Up to 5 user accounts", "Delivery analytics", "Phone support"], cta: "Start Business Plan", popular: true },
              { name: "ENTERPRISE", price: "Custom", note: "pricing", features: ["All Business features", "Dedicated account manager", "API integration", "Custom branding", "Bulk delivery discounts", "SLA guarantee"], cta: "Contact Sales" },
            ].map(p => (
              <div key={p.name} className={`relative rounded-2xl p-8 flex flex-col ${p.popular ? "bg-orange-500 border border-orange-400" : "bg-[#2A2A2E] border border-[#3A3A3E]"}`}>
                {p.popular && <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#F59E0B] text-[#1C1C1E] text-xs font-bold px-4 py-1 rounded-full">MOST POPULAR</div>}
                <div className={`font-display text-2xl tracking-widest mb-4 ${p.popular ? "text-white" : "text-orange-400"}`}>{p.name}</div>
                <div className="mb-1">
                  <span className={`font-display text-5xl ${p.popular ? "text-white" : "text-white"}`}>{p.price}</span>
                  <span className={`text-sm ml-2 ${p.popular ? "text-orange-100" : "text-gray-400"}`}>{p.note}</span>
                </div>
                <div className={`h-px my-6 ${p.popular ? "bg-orange-400" : "bg-[#3A3A3E]"}`} />
                <ul className="space-y-3 flex-1 mb-8">
                  {p.features.map(f => (
                    <li key={f} className={`flex items-center gap-2 text-sm ${p.popular ? "text-orange-50" : "text-gray-300"}`}>
                      <span className={p.popular ? "text-white" : "text-orange-500"}>✓</span>
                      {f}
                    </li>
                  ))}
                </ul>
                <Link href="/register" className={`text-center font-semibold py-3 rounded-full transition-all ${p.popular ? "bg-white text-orange-600 hover:bg-orange-50" : "bg-orange-500/10 border border-orange-500/50 text-orange-400 hover:bg-orange-500 hover:text-white"}`}>
                  {p.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-24 px-6 bg-[#2A2A2E]/30">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 text-center">
            <h2 className="font-display text-6xl"><span className="text-gradient">REAL PEOPLE.</span><br/>REAL RESULTS.</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map(t => (
              <div key={t.name} className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-8 hover:border-orange-500/30 transition-all hover:-translate-y-1">
                <div className="text-orange-500 text-2xl mb-4">"</div>
                <p className="text-gray-300 leading-relaxed mb-6 text-sm">{t.text}</p>
                <div>
                  <div className="font-semibold text-white">{t.name}</div>
                  <div className="text-gray-500 text-xs mt-0.5">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center relative">
          <div className="absolute inset-0 bg-orange-500/5 rounded-3xl border border-orange-500/20" />
          <div className="relative py-16 px-8">
            <h2 className="font-display text-7xl mb-6">READY TO<br/><span className="text-gradient">MOVE FASTER?</span></h2>
            <p className="text-gray-400 mb-10 max-w-lg mx-auto">Join thousands of businesses and riders already using MaruwaGo to transform delivery in Nigeria.</p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Link href="/register?role=business" className="bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold px-10 py-4 rounded-full transition-all hover:shadow-2xl hover:shadow-orange-500/40 hover:-translate-y-1 text-lg">
                Start as Business
              </Link>
              <Link href="/register?role=rider" className="border border-orange-500 text-orange-400 hover:bg-orange-500/10 font-semibold px-10 py-4 rounded-full transition-all text-lg">
                Register as Rider
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-[#2A2A2E] py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between gap-8 mb-12">
            <div>
              <div className="font-display text-4xl text-gradient mb-3">MARUWAGO</div>
              <p className="text-gray-500 text-sm max-w-xs">Nigeria's trusted tricycle delivery platform for SMEs and individuals.</p>
            </div>
            <div className="grid grid-cols-3 gap-12 text-sm">
              <div>
                <div className="text-white font-semibold mb-4">Platform</div>
                <ul className="space-y-2 text-gray-500">
                  <li><a href="#how" className="hover:text-white transition-colors">How It Works</a></li>
                  <li><Link href="/register" className="hover:text-white transition-colors">Sign Up</Link></li>
                  <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                </ul>
              </div>
              <div>
                <div className="text-white font-semibold mb-4">Riders</div>
                <ul className="space-y-2 text-gray-500">
                  <li><Link href="/register?role=rider" className="hover:text-white transition-colors">Join as Rider</Link></li>
                  <li><a href="#" className="hover:text-white transition-colors">Earnings</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Safety</a></li>
                </ul>
              </div>
              <div>
                <div className="text-white font-semibold mb-4">Company</div>
                <ul className="space-y-2 text-gray-500">
                  <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Privacy</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="border-t border-[#2A2A2E] pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-600 text-sm">© 2025 MaruwaGo. All rights reserved.</div>
            <div className="text-gray-600 text-sm">Made with ❤️ for Nigerian businesses</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
