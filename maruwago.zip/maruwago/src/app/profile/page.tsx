"use client";
import Link from "next/link";
import { useState } from "react";

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("profile");

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body">
      <div className="border-b border-[#2A2A2E] px-8 h-16 flex items-center gap-4">
        <Link href="/dashboard/business" className="text-gray-400 hover:text-white text-sm">← Dashboard</Link>
        <div className="w-px h-5 bg-[#3A3A3E]" />
        <div className="font-display text-xl text-gradient">PROFILE & SETTINGS</div>
      </div>

      <div className="max-w-4xl mx-auto px-8 py-8">
        {/* Profile header */}
        <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-8 mb-6 flex items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-orange-500/20 border-2 border-orange-500/50 flex items-center justify-center text-4xl">🏪</div>
          <div className="flex-1">
            <h2 className="text-2xl font-semibold text-white">Adaora's Fashion Store</h2>
            <p className="text-gray-400 text-sm mt-1">adaora@fashionstore.ng · +234 801 234 5678</p>
            <div className="flex items-center gap-3 mt-3">
              <span className="text-xs bg-green-500/10 text-green-400 border border-green-500/30 px-3 py-1 rounded-full">✓ Verified Business</span>
              <span className="text-xs bg-orange-500/10 text-orange-400 border border-orange-500/30 px-3 py-1 rounded-full">Business Plan</span>
            </div>
          </div>
          <button className="border border-[#3A3A3E] hover:border-orange-500/30 text-gray-400 hover:text-white px-5 py-2.5 rounded-xl text-sm transition-all">Edit Profile</button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-[#2A2A2E] p-1.5 rounded-xl mb-6 w-fit">
          {["profile", "security", "notifications", "billing", "wallet"].map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-5 py-2 rounded-lg text-sm font-medium capitalize transition-all ${activeTab === t ? "bg-orange-500 text-white shadow-lg shadow-orange-500/20" : "text-gray-400 hover:text-white"}`}
            >
              {t}
            </button>
          ))}
        </div>

        {activeTab === "profile" && (
          <div className="space-y-6">
            <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-6">
              <h3 className="font-semibold text-white mb-5">Business Information</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: "First Name", value: "Adaora", type: "text" },
                  { label: "Last Name", value: "Nwosu", type: "text" },
                  { label: "Email Address", value: "adaora@fashionstore.ng", type: "email" },
                  { label: "Phone Number", value: "+234 801 234 5678", type: "tel" },
                  { label: "Business Name", value: "Adaora's Fashion Store", type: "text" },
                  { label: "Business Type", value: "Fashion & Clothing", type: "text" },
                  { label: "Operating City", value: "Lagos", type: "text" },
                  { label: "Address", value: "32 Allen Avenue, Ikeja", type: "text" },
                ].map(f => (
                  <div key={f.label}>
                    <label className="block text-xs text-gray-500 mb-1.5">{f.label}</label>
                    <input type={f.type} defaultValue={f.value} className="w-full bg-[#1C1C1E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white text-sm outline-none" />
                  </div>
                ))}
              </div>
              <button className="mt-5 bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold px-6 py-3 rounded-xl text-sm transition-all hover:shadow-lg hover:shadow-orange-500/30">Save Changes</button>
            </div>
          </div>
        )}

        {activeTab === "wallet" && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-orange-500 to-orange-700 rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute inset-0 opacity-10" style={{backgroundImage: "repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%)", backgroundSize: "10px 10px"}} />
              <div className="relative">
                <div className="text-orange-100 text-sm mb-2">Wallet Balance</div>
                <div className="font-display text-6xl text-white">₦45,200</div>
                <div className="text-orange-200 text-sm mt-2">Adaora's Fashion Store</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <button className="bg-[#2A2A2E] border border-[#3A3A3E] hover:border-orange-500/30 rounded-2xl p-5 text-center transition-all">
                <div className="text-2xl mb-2">💳</div>
                <div className="text-white font-semibold">Fund Wallet</div>
                <div className="text-gray-500 text-xs mt-1">Add money via card or bank transfer</div>
              </button>
              <button className="bg-[#2A2A2E] border border-[#3A3A3E] hover:border-orange-500/30 rounded-2xl p-5 text-center transition-all">
                <div className="text-2xl mb-2">📊</div>
                <div className="text-white font-semibold">Transactions</div>
                <div className="text-gray-500 text-xs mt-1">View your spending history</div>
              </button>
            </div>
          </div>
        )}

        {activeTab === "notifications" && (
          <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-6">
            <h3 className="font-semibold text-white mb-5">Notification Preferences</h3>
            <div className="space-y-4">
              {[
                { label: "Delivery Status Updates", desc: "Get notified when your package is picked up, in transit, or delivered", on: true },
                { label: "Rider Assigned", desc: "Know immediately when a rider accepts your order", on: true },
                { label: "Delivery Confirmed", desc: "Recipient signature or confirmation alerts", on: true },
                { label: "Promotions & Offers", desc: "Discounts and special deals from MaruwaGo", on: false },
                { label: "Weekly Summary", desc: "A report of your delivery activity each week", on: false },
              ].map(n => (
                <div key={n.label} className="flex items-start justify-between gap-4 py-3 border-b border-[#3A3A3E] last:border-0">
                  <div>
                    <div className="text-white text-sm font-medium">{n.label}</div>
                    <div className="text-gray-500 text-xs mt-0.5">{n.desc}</div>
                  </div>
                  <div className={`w-11 h-6 rounded-full flex-shrink-0 relative cursor-pointer transition-all ${n.on ? "bg-orange-500" : "bg-[#3A3A3E]"}`}>
                    <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${n.on ? "left-6" : "left-1"}`} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {(activeTab === "security" || activeTab === "billing") && (
          <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-2xl p-8 text-center">
            <div className="text-4xl mb-4">{activeTab === "security" ? "🔐" : "💳"}</div>
            <h3 className="font-semibold text-white mb-2">{activeTab === "security" ? "Security Settings" : "Billing & Plans"}</h3>
            <p className="text-gray-500 text-sm">This section is fully implemented in the complete version.</p>
          </div>
        )}
      </div>
    </div>
  );
}
