"use client";
import Link from "next/link";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";

function RegisterContent() {
  const searchParams = useSearchParams();
  const defaultRole = searchParams.get("role") as "business" | "rider" | null;
  const [role, setRole] = useState<"business" | "rider">(defaultRole || "business");
  const [step, setStep] = useState(1);

  const businessTypes = ["Retail Store", "Restaurant / Food", "Fashion & Clothing", "Electronics", "Pharmacy", "Other"];

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body py-12 px-6">
      <div className="max-w-lg mx-auto">
        <div className="mb-8">
          <Link href="/" className="font-display text-3xl text-gradient">MARUWAGO</Link>
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-2 mb-10">
          {[1, 2, 3].map(s => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all ${step >= s ? "bg-orange-500 text-white" : "bg-[#2A2A2E] text-gray-500 border border-[#3A3A3E]"}`}>
                {s}
              </div>
              {s < 3 && <div className={`flex-1 h-px w-16 ${step > s ? "bg-orange-500" : "bg-[#3A3A3E]"}`} />}
            </div>
          ))}
          <div className="ml-4 text-sm text-gray-400">
            Step {step} of 3 — {step === 1 ? "Choose Role" : step === 2 ? "Your Details" : "Confirmation"}
          </div>
        </div>

        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h1 className="font-display text-5xl text-white tracking-wide mb-2">JOIN MARUWAGO</h1>
              <p className="text-gray-400">Choose how you want to use the platform</p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <button
                onClick={() => setRole("business")}
                className={`p-6 rounded-2xl border-2 text-left transition-all ${role === "business" ? "border-orange-500 bg-orange-500/10" : "border-[#3A3A3E] bg-[#2A2A2E] hover:border-[#5A5A5E]"}`}
              >
                <div className="flex items-start gap-4">
                  <div className="text-3xl">🏪</div>
                  <div>
                    <div className="font-semibold text-white text-lg mb-1">Business / Individual Owner</div>
                    <div className="text-gray-400 text-sm">Send packages, manage deliveries, track shipments for your business or personal needs.</div>
                    <div className="flex gap-2 mt-3 flex-wrap">
                      {["SME", "Online Store", "Restaurant", "Individual"].map(t => (
                        <span key={t} className="text-xs bg-[#3A3A3E] text-gray-300 px-2 py-1 rounded-full">{t}</span>
                      ))}
                    </div>
                  </div>
                </div>
                {role === "business" && <div className="absolute top-4 right-4 w-5 h-5 bg-orange-500 rounded-full flex items-center justify-center text-white text-xs">✓</div>}
              </button>

              <button
                onClick={() => setRole("rider")}
                className={`p-6 rounded-2xl border-2 text-left transition-all ${role === "rider" ? "border-orange-500 bg-orange-500/10" : "border-[#3A3A3E] bg-[#2A2A2E] hover:border-[#5A5A5E]"}`}
              >
                <div className="flex items-start gap-4">
                  <div className="text-3xl">🛺</div>
                  <div>
                    <div className="font-semibold text-white text-lg mb-1">Maruwa Rider / Owner</div>
                    <div className="text-gray-400 text-sm">Accept delivery jobs, earn income, and grow your Maruwa business with steady work.</div>
                    <div className="flex gap-2 mt-3 flex-wrap">
                      {["Earn Daily", "Flexible Hours", "Fast Payouts"].map(t => (
                        <span key={t} className="text-xs bg-[#3A3A3E] text-gray-300 px-2 py-1 rounded-full">{t}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </button>
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold py-3.5 rounded-xl transition-all hover:shadow-xl hover:shadow-orange-500/30"
            >
              Continue as {role === "business" ? "Business" : "Rider"} →
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h1 className="font-display text-5xl text-white tracking-wide mb-2">
                {role === "business" ? "BUSINESS DETAILS" : "RIDER DETAILS"}
              </h1>
              <p className="text-gray-400">Fill in your information to get started</p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">First Name</label>
                  <input className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="John" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Last Name</label>
                  <input className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="Doe" />
                </div>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Email Address</label>
                <input type="email" className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="you@example.com" />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Phone Number</label>
                <div className="flex gap-2">
                  <div className="bg-[#2A2A2E] border border-[#3A3A3E] rounded-xl px-3 py-3 text-gray-400 text-sm whitespace-nowrap">🇳🇬 +234</div>
                  <input className="flex-1 bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="0801 234 5678" />
                </div>
              </div>
              {role === "business" ? (
                <>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Business Name</label>
                    <input className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="Your Business Name" />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Business Type</label>
                    <select className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white outline-none">
                      {businessTypes.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Tricycle Plate Number</label>
                    <input className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="e.g. ABC-123-XY" />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Operating Area</label>
                    <input className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="e.g. Ikeja, Lagos" />
                  </div>
                </>
              )}
              <div>
                <label className="block text-sm text-gray-400 mb-2">Password</label>
                <input type="password" className="w-full bg-[#2A2A2E] border border-[#3A3A3E] focus:border-orange-500 rounded-xl px-4 py-3 text-white placeholder-gray-600 outline-none" placeholder="Min. 8 characters" />
              </div>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep(1)} className="flex-1 border border-[#3A3A3E] text-gray-300 hover:border-[#5A5A5E] font-semibold py-3.5 rounded-xl transition-all">
                ← Back
              </button>
              <button onClick={() => setStep(3)} className="flex-2 flex-[2] bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold py-3.5 rounded-xl transition-all hover:shadow-xl hover:shadow-orange-500/30">
                Create Account →
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="text-center space-y-6 py-12">
            <div className="w-20 h-20 bg-orange-500/20 border-2 border-orange-500 rounded-full flex items-center justify-center text-4xl mx-auto animate-pulse">
              ✓
            </div>
            <h1 className="font-display text-5xl text-white">ACCOUNT CREATED!</h1>
            <p className="text-gray-400 max-w-sm mx-auto">
              {role === "business"
                ? "Your business account is ready. Start booking deliveries right away."
                : "Your rider profile is under review. We'll notify you within 24 hours once verified."}
            </p>
            <Link
              href={role === "business" ? "/dashboard/business" : "/dashboard/rider"}
              className="inline-block bg-[#F97316] hover:bg-[#FF4500] text-white font-semibold px-10 py-3.5 rounded-full transition-all hover:shadow-xl hover:shadow-orange-500/30"
            >
              {role === "business" ? "Go to Dashboard →" : "View Rider Dashboard →"}
            </Link>
          </div>
        )}

        <p className="text-center text-gray-500 text-sm mt-8">
          Already have an account?{" "}
          <Link href="/login" className="text-orange-400 hover:text-orange-300 font-semibold">Sign in</Link>
        </p>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#1C1C1E] flex items-center justify-center text-white">Loading...</div>}>
      <RegisterContent />
    </Suspense>
  );
}
