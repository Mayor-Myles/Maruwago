"use client";
import Link from "next/link";
import { useState, useEffect } from "react";

const timeline = [
  { icon: "✅", label: "Order Placed", time: "2:14 PM", done: true },
  { icon: "🛺", label: "Rider Assigned — Emeka T.", time: "2:16 PM", done: true },
  { icon: "📍", label: "Package Picked Up", time: "2:31 PM", done: true },
  { icon: "🔄", label: "In Transit — Near Oshodi", time: "Now", done: false, active: true },
  { icon: "🏁", label: "Delivered to Recipient", time: "Est. 2:53 PM", done: false },
];

export default function TrackPage({ params }: { params: { id: string } }) {
  const [progress, setProgress] = useState(62);

  useEffect(() => {
    const t = setInterval(() => setProgress(p => Math.min(p + 0.5, 95)), 2000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen bg-[#1C1C1E] font-body">
      <div className="border-b border-[#2A2A2E] px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/business" className="text-gray-400 hover:text-white text-sm">← Dashboard</Link>
          <div className="w-px h-5 bg-[#3A3A3E]" />
          <div className="font-display text-xl text-gradient">TRACK ORDER</div>
          <span className="font-mono text-orange-400 text-sm">{params.id}</span>
        </div>
        <div className="flex items-center gap-2 bg-orange-500/10 border border-orange-500/30 px-4 py-1.5 rounded-full">
          <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" />
          <span className="text-orange-400 text-sm font-semibold">Live Tracking</span>
        </div>
      </div>

      <div className="flex h-[calc(100vh-64px)]">
        {/* Map panel */}
        <div className="flex-1 bg-[#2A2A2E] relative overflow-hidden">
          {/* Simulated map */}
          <div className="absolute inset-0" style={{backgroundImage: "linear-gradient(rgba(249,115,22,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(249,115,22,0.03) 1px, transparent 1px)", backgroundSize: "40px 40px"}} />
          
          {/* Route line */}
          <svg className="absolute inset-0 w-full h-full">
            <defs>
              <linearGradient id="routeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#F97316" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#22c55e" stopOpacity="0.8" />
              </linearGradient>
            </defs>
            <path d="M 150,400 Q 300,300 450,250 Q 550,200 600,150" stroke="url(#routeGrad)" strokeWidth="3" fill="none" strokeDasharray="8,4" />
          </svg>

          {/* Pickup marker */}
          <div className="absolute" style={{left: "18%", top: "72%"}}>
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-sm font-bold text-white border-2 border-white shadow-lg">A</div>
            <div className="text-xs text-white bg-[#1C1C1E] px-2 py-1 rounded mt-1 whitespace-nowrap border border-[#3A3A3E]">Allen Ave, Ikeja</div>
          </div>

          {/* Rider */}
          <div className="absolute" style={{left: "50%", top: "42%", transform: "translate(-50%, -50%)"}}>
            <div className="text-3xl animate-bounce">🛺</div>
            <div className="text-xs text-orange-400 text-center mt-1 font-semibold">Emeka</div>
          </div>

          {/* Dropoff marker */}
          <div className="absolute" style={{left: "78%", top: "18%"}}>
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-sm font-bold text-white border-2 border-white shadow-lg">B</div>
            <div className="text-xs text-white bg-[#1C1C1E] px-2 py-1 rounded mt-1 whitespace-nowrap border border-[#3A3A3E]">Broad St, Island</div>
          </div>

          {/* Map label */}
          <div className="absolute bottom-4 left-4 bg-[#1C1C1E]/80 backdrop-blur border border-[#3A3A3E] rounded-xl px-4 py-2 text-xs text-gray-400">
            🗺 Live map integration (Google Maps / Mapbox)
          </div>
        </div>

        {/* Info panel */}
        <div className="w-96 bg-[#1C1C1E] border-l border-[#2A2A2E] flex flex-col overflow-auto">
          {/* ETA */}
          <div className="p-6 border-b border-[#2A2A2E]">
            <div className="text-center">
              <div className="font-display text-6xl text-gradient">18</div>
              <div className="text-white font-semibold">minutes away</div>
              <div className="text-gray-500 text-sm mt-1">Est. arrival: 2:53 PM</div>
            </div>
            {/* Progress */}
            <div className="mt-5">
              <div className="flex justify-between text-xs text-gray-500 mb-1.5">
                <span>Pickup</span>
                <span>{Math.round(progress)}%</span>
                <span>Dropoff</span>
              </div>
              <div className="h-2 bg-[#3A3A3E] rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-orange-500 to-green-500 rounded-full transition-all duration-1000" style={{width: `${progress}%`}} />
              </div>
            </div>
          </div>

          {/* Rider info */}
          <div className="p-5 border-b border-[#2A2A2E]">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-orange-500/20 border border-orange-500/50 flex items-center justify-center text-xl">🛺</div>
              <div className="flex-1">
                <div className="text-white font-semibold">Emeka Okafor</div>
                <div className="text-gray-500 text-xs">⭐ 4.8 · 342 deliveries</div>
                <div className="text-gray-500 text-xs mt-0.5">Plate: LG-894-XA</div>
              </div>
              <button className="w-10 h-10 bg-[#2A2A2E] border border-[#3A3A3E] rounded-full flex items-center justify-center text-lg hover:border-orange-500/30 transition-colors">📞</button>
            </div>
          </div>

          {/* Timeline */}
          <div className="p-5 flex-1">
            <div className="text-sm font-semibold text-gray-400 mb-4 uppercase tracking-wider">Status Timeline</div>
            <div className="space-y-0">
              {timeline.map((item, i) => (
                <div key={item.label} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm flex-shrink-0 ${item.active ? "bg-orange-500 animate-pulse" : item.done ? "bg-green-500/20 border border-green-500/50" : "bg-[#2A2A2E] border border-[#3A3A3E]"}`}>
                      {item.icon}
                    </div>
                    {i < timeline.length - 1 && <div className={`w-px flex-1 my-1 min-h-[16px] ${item.done ? "bg-green-500/30" : "bg-[#3A3A3E]"}`} />}
                  </div>
                  <div className="pb-4">
                    <div className={`text-sm font-medium ${item.active ? "text-orange-400" : item.done ? "text-white" : "text-gray-500"}`}>
                      {item.label}
                    </div>
                    <div className="text-gray-600 text-xs mt-0.5">{item.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Order details */}
          <div className="p-5 border-t border-[#2A2A2E] bg-[#2A2A2E]/50">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><span className="text-gray-500 text-xs block">Order ID</span><span className="text-orange-400 font-mono">{params.id}</span></div>
              <div><span className="text-gray-500 text-xs block">Package</span><span className="text-white">Medium · Standard</span></div>
              <div><span className="text-gray-500 text-xs block">Distance</span><span className="text-white">14.2 km</span></div>
              <div><span className="text-gray-500 text-xs block">Total</span><span className="text-gradient font-display text-lg">₦1,200</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
